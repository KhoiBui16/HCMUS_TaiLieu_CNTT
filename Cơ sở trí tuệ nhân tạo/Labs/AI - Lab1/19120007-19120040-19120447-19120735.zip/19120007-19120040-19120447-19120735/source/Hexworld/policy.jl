include("visual.jl")

#struct of the policy
# we need 2 argument to init this struct
# using Setfield
struct Policy
    mdp::MDP
    U::Vector{Float64}
end

function rand_with_prob(Values::Vector{Float64}, Probs::Vector{Float64})
    sum_prob = sum(Prob for Prob in Probs)  # sum_prob = 1.0
    for i in 1 : length(Values)
        if rand(0.0 : .000000001 : sum_prob) <= Probs[i]
            return Values[i]
        end
        sum_prob -= Probs[i]
    end
end

# lookahead return value for each action (a) at state (s)
function lookahead(mdp::MDP, U::Vector{Float64}, s::Int64, a::Int64, is_deterministic::Bool)
    𝒮, T, R, γ = mdp.𝒮, mdp.T, mdp.R, mdp.γ
    r = rand_with_prob(R[s, :], T[s, a, :])
    if is_deterministic
        r = sum(T[s, a, s′] * R[s, s′] for s′ in 𝒮)
    end
    return r + γ * sum(T[s, a, s′] * U[s′] for s′ in 𝒮)
end

#search for the policy (action should go)
function greedy(mdp::MDP, U::Vector{Float64}, s)
    u, a = findmax(a -> lookahead(mdp, U, s, a, true), mdp.𝒜)
    return (a = a, u = u)
end

#lamdba expression with type of function is ValueFunctionPolicy
#the argument is a state (it is a number)
(policy::Policy)(s) = greedy(policy.mdp, policy.U, s).a # tra ve so nguyen



function iterative_policy_evaluation(policy::Policy, k_max::Int, method::Int)
    mdp = policy.mdp
    𝒮 = mdp.𝒮
    U = zeros(Float64, length(𝒮))
    for k in 1 : k_max
        U = [lookahead(mdp, U, s, policy(s), method == 2) for s in 𝒮]
    end
    return U
end

#call this function in main to solve this problem
function Solve(
    policy::Policy, 
    k_max::Int, 
    hexes::Vector{Tuple{Int, Int}}, 
    method::Int
)
    mdp = policy.mdp
    𝒮 = mdp.𝒮
    for k = 1 : k_max
        print("$k ")
        U = iterative_policy_evaluation(policy, k_max, method::Int)
        policy′ = Policy(mdp, U)

        visual("visual$k.png", hexes, [policy(s) for s in 𝒮], U, "none")

        if all(policy(s) == policy′(s) for s in 𝒮)
            policy = policy′
            U = iterative_policy_evaluation(policy, k_max, method)
            println()
            println("Num of loops: $k")
            visual("visual_res.png", hexes, [policy(s) for s in 𝒮], U, "none")
            return [policy(s) for s in 𝒮]
        end
        policy = policy′
    end
end



