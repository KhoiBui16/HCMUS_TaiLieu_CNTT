include("mdp.jl")
include("map.jl")

# --- Hàm tìm các ô lân cận ---
function hex_neighbors(hex::Tuple{Int,Int})
    i, j = hex
    return [(i, j + 1), (i - 1, j + 1), (i - 1, j), (i, j - 1), (i + 1, j - 1), (i + 1, j)]
end

struct HexWorldMDP
    # Bài toán có |hexes| + 1 trạng thái, gôm các ô và trạng thái cuối.
    hexes   ::Vector{Tuple{Int,Int}}
    # Tạo một discreateMDP
    dMDP    ::DiscreteMDP
    # Phần thưởng hex đặc biệt được sử dụng để tạo MDP, key
    special_hex_rewards ::Dict{Tuple{Int,Int},Float64}
end

function HexWorldMDP(
    hexes::Vector{Tuple{Int,Int}},  # set of states [(a_1,b_2),(a_2,b_2)]
    r_bump_border::Float64,         # actions rewards
    p_intended::Float64,            # probability [0,1]
    special_hex_rewards::Dict{Tuple{Int,Int},Float64},  #reward
    γ::Float64,                     #discunted rate [0,1]
)
    nS = length(hexes) + 1 #number of state (last state is consuming state)
    nA = 6   #number of actions, In this problems we have six directions
    s_absorbing = nS # terminal state

    T = zeros(Float64, nS, nA, nS)  #init transition (probability) [0,1]
    R = zeros(Float64, nS, nS)      #action [1,6] because we have 6 choice to go

    p_veer = (1.0 - p_intended) / 2 # probability of veering left or right

    for s in 1 : length(hexes)
        hex = hexes[s]
        if !haskey(special_hex_rewards, hex)  #kiểm tra xem trong các states đã đi có key hex hay chưa
            # Action taken from a normal tile
            neighbors = hex_neighbors(hex)  #trả về 1 mảng 6 vị trí lân cận
            for (a,neigh) in enumerate(neighbors)  # a là index được đánh số từ 1, neigh là cặp các tupel tương ứng (i,j+1),...
                # Intended transition.
                s′ = findfirst(h -> h == neigh, hexes) #s' là state ở (t+1) #findFirst trả về index đầu tiên == neigh trong tập hexes
                if s′ == nothing # Off the map!
                    s′ = s
                end
                T[s,a,s′] += p_intended  #tính tỷ lệ đi đến state 
                
                # Unintended veer left.
                a_left = mod1(a+1, nA)
                neigh_left = neighbors[a_left]
                s′ = findfirst(h -> h == neigh_left, hexes)
                if s′ == nothing # Off the map!
                    s′ = s
                end
                T[s,a,s′] += p_veer
               
                # Unintended veer right.
                a_right = mod1(a-1, nA) # 0%6=6
                neigh_right = neighbors[a_right]
                s′ = findfirst(h -> h == neigh_right, hexes)
                if s′ == nothing # Off the map!
                    s′ = s
                end
                T[s,a,s′] += p_veer
            end
            # Bump_border reward.
            R[s,s] += r_bump_border*p_intended
        else # nếu mảng Reward đã chứa key hex
            # Action taken from an absorbing hex
            # In absorbing hex, your action automatically takes you to the absorbing state and you get the reward.
            for a in 1 : nA
                T[s,a,s_absorbing] = 1.0  #get the reward and can return to the terminal state
            end
            R[s,s_absorbing] += special_hex_rewards[hex]
        end
    end

    # Absorbing state stays where it is and gets no reward.
    for a in 1:nA
        T[s_absorbing, a, s_absorbing] = 1.0  #terminal state
    end

    mdp = DiscreteMDP(T, R, γ)  #init the MDPdiscrete which is defined in mdp.jl file

    return HexWorldMDP(hexes, mdp, special_hex_rewards)
end


const HexWorldRBumpBorder = -1.0 # Reward for falling off hex map -> (bounded by the border)
const HexWorldPIntended = 0.7 # Probability of going intended direction (go the right direction)
const HexWorldDiscountFactor = 0.9  #--> discounted rate (γ)


# this function is used to init a hexworld with rewards
function HexWorld()
    hexes, rewards = map3
    return HexWorldMDP(hexes, HexWorldRBumpBorder, HexWorldPIntended, rewards, HexWorldDiscountFactor)
end
