include("hexworld.jl")
include("mdp.jl")
include("Policy.jl")


# --- Mô hình hoá bài toán ---
hwMDP = HexWorld()      # Tạo một HexWorldMDP
mdp = MDP(hwMDP.dMDP)   # Tạo một MDP từ HexWorldMDP


# --- Tạo policy và k_max ---
k_max = 100
U = zeros(Float64, length(hwMDP.hexes) + 1)
policy = Policy(mdp, U)


# Cài phương pháp muốn chạy:
#   method == 1  -->    phương pháp cơ bản
#   method == 2  -->    phương pháp cải tiến
# Mặc định là method = 2
method = 2
if length(ARGS) > 0
    if ARGS[1] == "1"
        method = 1
    end
end


# Giải quyết bài toán, gọi hàm Solve trong file policy.jl
actions = Solve(policy, k_max,  hwMDP.hexes, method)




# ------------------------------------------------------------------------------------- Phần visualization
foreach(rm, filter(endswith(".png"), readdir("visualization/",join=true)))
U = zeros(Float64, length(hwMDP.hexes) + 1)
for i in 1 : length(hwMDP.hexes)
    if haskey(hwMDP.special_hex_rewards, hwMDP.hexes[i])
        U[i] = hwMDP.special_hex_rewards[hwMDP.hexes[i]]
    end
end
visual("visual_coor.png", hwMDP.hexes, zeros(Int, length(hwMDP.hexes)), U, "coor")
visual("visual_reward.png", hwMDP.hexes, zeros(Int, length(hwMDP.hexes)), U, "reward")
visual("visual0.png", hwMDP.hexes, ones(Int, length(hwMDP.hexes)), U, "none")
# --------------------------------------------------------------------------------------
