using Luxor

include("hexWorld.jl")

function to_color(red::Int, green::Int, blue::Int)
    res = "#"
    hexchar = ["A", "B", "C", "D", "E", "F"]
    for cl in (red,green,blue)
        for it in (div(cl,16) , cl%16)
            it = min(max(it, 0), 15)
            if it > 9
                res *= hexchar[it-9]
            else
                res *= string(it)
            end
        end
    end
    return res
end

function visual(filename::String, hexes::Vector{Tuple{Int, Int}}, actions::Vector{Int}, U::Vector{Float64}, txt::String)
    Drawing(520,180, "visualization/"*filename)
    background("white")

    radius = 30
    num_cell_a_line = 15

    grid_point = [[Point(0,0) for j in 1:100 + num_cell_a_line] for i in 1:100 + 2*num_cell_a_line]
    grid = GridHex(O, radius, 770)
    for idx in 1:300
        p = nextgridpoint(grid)

        j = mod1(idx, num_cell_a_line)
        i = Int((idx - j) / num_cell_a_line)
        j -= Int((i-i%2)/2)
        j -= 1
        i -= 1

        grid_point[i+100][j+100] = p
    end

    
    for idx in 1:length(hexes)
        (i,j) = hexes[idx]
        p = grid_point[i+100][j+100]
        r=255
        g=255
        b=255
        deviant = 20
        base = 220
        sethue("#444488")
        if U[idx] < 0
            g = base - round(Int, deviant*(-U[idx]))
            b = base - round(Int, deviant*(-U[idx]))
            sethue("#884444")
        end
        if U[idx] > 0
            r = base - round(Int, deviant*U[idx])
            g = base - round(Int, deviant*U[idx])
        end
        ngon(p, radius-3, 6, pi/2, :fillstroke)
        sethue(to_color(r,g,b))
        ngon(p, radius-5, 6, pi/2, :fillstroke)

        if actions[idx] >= 1 && actions[idx] <= 6
            (ni,nj) = hex_neighbors(hexes[idx])[actions[idx]]
            next = grid_point[ni+100][nj+100]
            sethue("#555555")
            arrow(p, between(p, next, 0.4), arrowheadlength=16, arrowheadangle=pi/4, linewidth=0)
        end

        if txt[1] == 'c'
            fontsize(15)
            sethue("black")
            text("(" * string(i) * ";" * string(j) * ")", p, halign=:center, valign=:middle)
        elseif txt[1] == 'r'
            if U[idx] == 0
                continue
            end
            fontsize(20)
            sethue("black")
            text(string(Int(U[idx])), p, halign=:center, valign=:middle)
        end
    end

    finish()
    preview()
end

