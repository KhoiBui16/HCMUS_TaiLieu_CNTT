struct MDP
    γ::Float64                  # discount factor
    𝒮::Array{Int}           # state space
    𝒜::Array{Int}           # action space
    T::Array{Float64, 3}    # transition function
    R::Array{Float64, 2}    # reward function
    TR                      # sample transition and reward
end

struct DiscreteMDP
    T::Array{Float64, 3} 
    R::Array{Float64, 2}
    γ::Float64
end

#constructor MDP from DiscreteMDP
function MDP(dMDP::DiscreteMDP)
    return MDP(dMDP.γ, 1:size(dMDP.T, 1), 1:size(dMDP.T, 2), dMDP.T, dMDP.R, nothing)
end

